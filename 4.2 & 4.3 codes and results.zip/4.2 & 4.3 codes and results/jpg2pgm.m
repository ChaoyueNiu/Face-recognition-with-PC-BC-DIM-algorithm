 function [  ] = jpg2pgm(  )  

 pgms = dir('F:\KINGS ROBOTICS MATERIALS\individual project\FFFFFFFFFFFace alignment\final  face  alignment\��������-automatically\64 by 64\s40\*.jpg');  
 num_pgms = length( pgms );  
 for i = 1 : num_pgms  
   pgm_file = fullfile( 'F:\KINGS ROBOTICS MATERIALS\individual project\FFFFFFFFFFFace alignment\final  face  alignment\��������-automatically\64 by 64\s40\' , pgms(i).name );  
   pgm = imread( pgm_file );  

   [ path , name , ext ] = fileparts( pgm_file ) ;  

   filename = strcat( name , '.pgm' );  

   jpg_file = fullfile( 'F:\KINGS ROBOTICS MATERIALS\individual project\FFFFFFFFFFFace alignment\final  face  alignment\��������-automatically\64 by 64\s40\' , filename ) ;  
    
  imwrite( pgm , jpg_file , 'pgm' );  
  
 end  
  
end 