function centre=centroid(W,x,y,z)
%calculate the "centre of mass" of a matrix
[a,b,c]=size(W);
if nargin<2 || isempty(x)
  x=1:b;
end
if nargin<3 || isempty(y)
  y=1:a;
end
if nargin<4 || isempty(z)
  z=1:c;
end

sumW = max(1e-9,sum(W(:)));

Wxy=sum(W,3);
centre(1) = sum(sum(Wxy,1).*x)/sumW;
centre(2) = sum(sum(Wxy,2)'.*y)/sumW;

if c>1
  Wyz(:,:)=sum(W,1);
  centre(3) = sum(sum(Wyz,1).*z)/sumW;
end