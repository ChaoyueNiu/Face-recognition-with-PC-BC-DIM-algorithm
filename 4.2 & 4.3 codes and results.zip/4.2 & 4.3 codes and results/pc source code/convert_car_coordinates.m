function [pos,width,height]=convert_car_coordinates(pos,scale)
if nargin<2 || isempty(scale), scale=1; end

%size of bounding box (100x40 for scale=1 or single scale images)
width=100.*scale.*ones(1,size(pos,2));
height=40.*scale.*ones(1,size(pos,2));

%reposition estimate of car position from centre of car to top-left corner of bounding box
pos(1,:)=pos(1,:)-width./2;
pos(2,:)=pos(2,:)-height./2;

%swap the order of the coordinates as UIUC data uses row,column format
pos=flipud(pos);

