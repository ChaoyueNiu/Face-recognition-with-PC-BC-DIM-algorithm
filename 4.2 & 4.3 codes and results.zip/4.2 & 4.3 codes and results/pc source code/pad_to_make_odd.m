function w=pad_to_make_odd(w)
[n,m,l]=size(w);
if n==2*floor(n/2)
  w=[w;zeros(1,m,l)];
end
[n,m,l]=size(w);
if m==2*floor(m/2)
  w=[w,zeros(n,1,l)];
end
