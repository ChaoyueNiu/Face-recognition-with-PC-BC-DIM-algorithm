function [w,v]=define_dictionary(patches,ONOFF,sigmaLGN,scales)
if nargin<4 || isempty(scales), scales=1; end
[numTemplates,patchLen]=size(patches);
patchLen=sqrt(patchLen);
patchHalfLen=(patchLen-1)/2;
numScales=length(scales);

if min(min(patches))<0
  normApprox=0
else
  normApprox=1
end

%place templates in dictionary/weights
%if ONOFF && ~normApprox, [~,~,X{1},X{2}]=imnorm(I,sigmaLGN); end
for s=1:numScales
  for j=1:numTemplates
    template=reshape(patches(j,:),patchLen,patchLen);
    jj=(s-1)*numTemplates+j;
    template=imresize(template,scales(s),'bilinear');
    %template=imsetsize(template,[patchLen,patchLen],mean(template(:)));
    if ONOFF
      if normApprox
        [~,~,w{jj,1},w{jj,2}]=imnorm(template,sigmaLGN);
      else
        w{jj,1}=template;
        w{jj,1}(w{jj,1}<0)=0;
        w{jj,2}=-template;
        w{jj,2}(w{jj,2}<0)=0;
        %w{jj,1}=extract_patch(X{1},patchHalfLen,keypoints(j,1:2));
        %w{jj,2}=extract_patch(X{2},patchHalfLen,keypoints(j,1:2));
      end
    else
      [v{jj,1},w{jj,1}]=convert_to_weights(template);
    end
  end
end
[w,v]=normalise_dim_weights(w);

%Add extra weights - basis functions
%angleStep=15; angles=[0:angleStep:360-0.01];
%[w,v]=filter_definitions_diffboundary(w,v,[],[],patchHalfLen,sigmaLGN,0.3,angles,0,0);
%[w,v]=filter_definitions_gabor(w,v,[],1,patchHalfLen/2,angles,[],[],0);
size(w,1)
