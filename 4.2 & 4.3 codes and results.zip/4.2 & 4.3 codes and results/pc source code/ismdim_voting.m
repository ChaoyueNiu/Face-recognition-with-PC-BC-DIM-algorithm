function [H,W]=ismdim_voting(Locations,I)
numFeatureMaps=length(I);
numClasses=size(Locations,1);
[a,b]=size(I{1});

%define weights only for those inputs which are non-zero: weights will be
%specific to one particlular calculation (i.e. one specific image), but will
%require much less memory (assuming input is sparse) than defining weights for
%all inputs. Defining weights for all inputs can be done using the convolutional
%implementation of DIM so that we only need to store the convolution kernels,
%not many copies of the same weights, but this is much slower!

%for each class (=output channel) calc max weight accross all input
%channels. This will be used for calculating V (need to do this manually as some
%weights are not included in matix sent to dim_activation - hence, V can not be
%calculated locally by dim_activation by normalising W in the normal way)
wmax=zeros(1,numClasses,'single');
for i=1:numFeatureMaps
  for c=1:numClasses
    wmax(c)=max(wmax(c),max(max(Locations{c,i})));
  end
end
%wmaxmax=max(wmax);

Itotal=single([]);
k=0;
for i=1:numFeatureMaps
  [x,y]=find(I{i}>0);
  for j=1:length(x)
    k=k+1;
    %record non-zero values for input to neural network
    Itotal(k,1)=I{i}(x(j),y(j));
        
    %define Hough votes as weights fanning out from one input pixel
    FmapTmp=zeros(a,b);
    FmapTmp(x(j),y(j))=1;
        
    wcolumn=[];
    vcolumnScale=[];
    for c=1:numClasses
      wtmp=conv2(FmapTmp,rot90(Locations{c,i},2),'same');
      wcolumn=[wcolumn;wtmp(:)];
      vcolumnScale=[vcolumnScale;ones(size(wtmp(:))).*wmax(c)];%V will be W scaled by wmax(c)
    end
    W(:,k)=single(wcolumn);
  end
end
[n,m]=size(W);

if isempty(Itotal)
  H=zeros(a,b,numClasses);
else
  %ignore neurons with zero weights to improve speed.
  inc=find(sum(W,2)>0);
  %apply PC/BC-DIM to process the inputs
  yinc=dim_activation(W(inc,:),Itotal,bsxfun(@rdivide,W(inc,:),vcolumnScale(inc))); 
  %yinc=dim_activation(W(inc,:),Itotal,W(inc,:)./wmaxmax); 
  %put zero activations for neurons with zero weights
  y=zeros(n,1);
  y(inc)=yinc;
  H=reshape(y,a,b,numClasses);
end
