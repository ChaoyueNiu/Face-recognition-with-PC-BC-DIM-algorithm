function [w,v]=normalise_dim_weights(w)
[numMasks,numChannels]=size(w);

for j=1:numMasks
  normW=0;
  normV=0;
  for i=1:numChannels
    normW=normW+sum(sum(w{j,i}));
    normV=max(normV,max(max(w{j,i})));
  end
  normW=max(1e-6,normW);
  normV=max(1e-6,normV);
  
  for i=1:numChannels
    v{j,i}=w{j,i}./normV;
    w{j,i}=w{j,i}./normW;      
  end
end
