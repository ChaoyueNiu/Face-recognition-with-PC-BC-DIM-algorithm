function [patches,usedpoints]=extract_patches(I,hlen,num,method,priority,sigmaLGN)
if nargin<4 || isempty(method)
  method='corner';
end
%disp(['extract_patches ',method]);

j=0;
usedpoints=[];patches=[];
%find the keypoints
switch method
  case 'random'
    keypoints = random_keypoints(I(:,:,1),5*num);
  case 'corner'
    keypoints = corner(I(:,:,1)',5*num);
  case 'siftandcorner'
    if ~exist('vl_version.m','file')
      run('/home/mike/Utils/Matlab/Toolboxes/vlfeat-0.9.20/toolbox/vl_setup');
    end
    keypoints = ceil(vl_sift(single(I(:,:,1)'))');
    keypoints = [keypoints(:,1:2);corner(I(:,:,1)',3*num)];
    keypoints = unique(keypoints,'rows','stable');
  case 'priority'
    [val,ind]=sort(priority(:),'descend');
    [a,b]=size(priority);[x,y]=meshgrid(1:b,1:a);
    keypoints(:,1)=y(ind(1:2*num));
    keypoints(:,2)=x(ind(1:2*num));
end

if nargin>5 && ~isempty(sigmaLGN)
  disp('extracting hf patches');
  I=imnorm(I,sigmaLGN);
end

for k=1:size(keypoints,1);
  %for each keypoint extract a patch of image around that keypoint
  Ipatch=extract_patch(I,hlen,keypoints(k,1:2));

  if 0 & ~isnan(Ipatch)
    centOrig=centroid(abs(Ipatch));
    for i=1:20
      cent=centroid(abs(Ipatch));
      keypoints(k,1)=keypoints(k,1)-round(hlen+1-cent(2));
      keypoints(k,2)=keypoints(k,2)-round(hlen+1-cent(1));
      Ipatch=extract_patch(I,hlen,keypoints(k,1:2));
    end
    distMoved=sqrt(sum((cent-centOrig).^2))
  end
  
  if ~isnan(Ipatch)
    j=j+1;
    usedpoints(j,:)=keypoints(k,:);
    patches(j,:)=Ipatch(:)';
  end
  if j>=num, return; end
end
%disp(['extracted ',int2str(j),' image patches'])




function points=random_keypoints(I,num)

[a,b]=size(I);
points(1:num*2,1)=randi(a,num*2,1);
points(1:num*2,2)=randi(b,num*2,1);
points=unique(points,'rows');
ind=randperm(size(points,1));
points=points(ind(1:min(num,length(ind))),1:2);



