function [params,stats]=stats_ismdim_carsScale(params,thresholds)
if nargin<2 || isempty(thresholds)
  thresholds=[0.1:0.05:2]; 
end
numTest=108;
scales=1.2.^[-1:4] %6 scales

makeScaleLarge=1;%./min(scales)
scales=scales.*makeScaleLarge

if nargin<1 || isempty(params)
  spread=2
  amp=2
  
  %DEFINE CODEBOOK
  load('ISMDIM_codebook_carsScale.mat');
 
  [Locations,patchClassList]=postprocess_codebook(Locations,patchClassList,spread,amp,scales);


  %FOR EACH TEST IMAGE PERFORM ISM TO LOCATE CARS
  disp(['Processing Images (',int2str(numTest),')'])
  params{numTest}=[];%pre-allocate memory
  for i=1:numTest
    fprintf(1,'.%i.',i);
    %load image and display
    I=load_image_car(i-1,4);
    
    I=imresize(I,makeScaleLarge,'bilinear');

    %APPLY METHODS
    [params{i}]=ismdim_matching(I,patches,patchClassList,Locations,sigmaLGN,scales);
  end
end

%FOR EACH METHOD AND THRESHOLD TEST ACCURACY WITH WHICH CARS ARE LOCATED
filename=['estimated_carScale_locations',int2str(randi(100000)),'.txt']
[~,data_dir]=load_image_car(1,4);

disp('Testing Accuracy for threshold:')
t=0;
for thres=thresholds 
  t=t+1;
  fprintf(1,'.%2.2f.',thres);

  %record results for current threshold into a file
  file=fopen([data_dir,filename],'w');

  for i=1:numTest
    %find coordinates for which the votes exceed the threshold
    index=find(params{i}{1}(1,:)>thres);
    coords=params{i}{1}(2:3,index);
    scale=params{i}{1}(4,index);
    
    coords=coords./makeScaleLarge;
    scale=scale./makeScaleLarge;
    
    %store these coordinates in the results file
    [coords,widths]=convert_car_coordinates(coords,scale);
    write_result(i,[coords;widths],file);
  end    
  fclose(file);
  
  %evaluate the results using the java code supplied with the UIUC Cars dataset
  dir=pwd;
  cd(data_dir);
  [~,result]=system(['java Evaluator_Scale trueLocations_Scale.txt ',filename])
  stats(t,:)=parse_car_evaluation(result);
  cd(dir)
  
  f1score(t)=calc_f1score(stats(t,:));
end

%PLOT THE RESULTS
disp(['f1score ']);
disp(f1score)
[val,ind]=max(f1score); disp(['max f1score=',num2str(val),' at threshold=',num2str(thresholds(ind))]);

figured(11),clf
plot_errors(thresholds,stats,max(sum(stats(:,2:3),2)));

figured(12),clf
plot_precision_recall(stats,'r-^'); hold on

figured(13),clf
plot_RFPPI(stats,'r-^',numTest), hold on




function write_result(i,pos,file)
pos=pos(:);
fprintf(file,'%i: ',i-1);
if ~isnan(pos), fprintf(file,'(%i,%i,%i) ',round(pos)); end
fprintf(file,'\n');



function stats=parse_car_evaluation(result)
vals=sscanf(result,'%*cCorrect detections :%u out of%u%');
TP=vals(1);
FN=vals(2)-vals(1);

ind=strfind(result,'False detections   :');
FP=sscanf(result(ind:end),'False detections   :%u');

stats=[TP,FP,FN];