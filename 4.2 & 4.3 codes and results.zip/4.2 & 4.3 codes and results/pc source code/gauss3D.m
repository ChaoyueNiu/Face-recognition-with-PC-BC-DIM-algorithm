function gauss=gauss3D(sigmas)
%define grid of x,y,z coodinates at which to define function
pxsize=odd(5*sigmas);
cntr=ceil(pxsize./2);
[x y z]=meshgrid(1:pxsize(1),1:pxsize(2),1:pxsize(3));

%avoid division by zero errors
sigmas=max(1e-15,sigmas);

%define gaussian
gauss=exp(-.5*( (((x-cntr(1)).^2)./(sigmas(1)^2))+ ...
                (((y-cntr(2)).^2)./(sigmas(2)^2))+ ...
                (((z-cntr(3)).^2)./(sigmas(3)^2)) ));

gauss=gauss./sum(gauss(:));
