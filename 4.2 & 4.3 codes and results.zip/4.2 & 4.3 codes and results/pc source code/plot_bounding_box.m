function plot_bounding_box(coords,widths,heights,lineType)
%plot bounding boxes

if nargin<4 || isempty(lineType), lineType='y-'; end
for i=1:size(coords,2)
  x=coords(2,i);
  y=coords(1,i);
  plot([x,x,x+widths(i),x+widths(i),x],[y,y+heights(i),y+heights(i),y,y],lineType,'LineWidth',2);
end
