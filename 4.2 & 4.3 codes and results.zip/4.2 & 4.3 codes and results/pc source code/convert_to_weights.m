function [v,w]=convert_to_weights(t);
v=t;
%v=v-min(v(:));
v=v./max(v(:));

w=t;
w=w-min(w(:));
w=w./sum(w(:));

