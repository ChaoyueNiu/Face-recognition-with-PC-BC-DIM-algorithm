function plot_errors(thresholds,stats,max_error)
TP=stats(:,1);
FP=stats(:,2);
FN=stats(:,3);
len=size(stats,1);
bar(stats(:,2:3),'stacked');
set(gca,'FontSize',12);
set(gcf,'PaperSize',[20 9],'PaperPosition',[0.25 0.25 19.5 8.5]);
xlabel('threshold')
ylabel('errors (FP + FN)')
colormap('gray');
tolabel=[1:4:length(thresholds)];
set(gca,'XTick',tolabel,'XtickLabel',thresholds(tolabel));
axis([0.5,len+0.5,0,ceil(max_error+1)]);
