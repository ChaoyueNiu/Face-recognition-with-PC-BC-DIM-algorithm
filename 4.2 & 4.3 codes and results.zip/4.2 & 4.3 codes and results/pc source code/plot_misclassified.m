function plot_misclassified(classPredicted,classGroundtruth,data,imDims,plotPolarity,randorder)
wrong=find(classPredicted~=classGroundtruth);
if randorder, wrong=wrong(randperm(length(wrong))); end
wrong=wrong(1:min(length(wrong),48));

[a,b]=best_subplot_rows_cols(length(wrong));

for i=1:length(wrong), 
  maxsubplot(a,b,i);
  plot_image(reshape(data(wrong(i),1:prod(imDims)),imDims)'); 
  text(1,1,int2str(classGroundtruth(wrong(i))-1),'Units','normalized','VerticalAlignment','top','HorizontalAlignment','left','FontSize',12)
  text(1,0,int2str(classPredicted(wrong(i))-1),'Units','normalized','VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12)
end
cmap=colormap('gray'); if plotPolarity<0, cmap=1-cmap;colormap(cmap); end
set(gcf,'PaperSize',[1.5*b+1 a].*imDims./max(imDims),'PaperPosition',[0 0 [1.5*b a].*imDims./max(imDims)]);
