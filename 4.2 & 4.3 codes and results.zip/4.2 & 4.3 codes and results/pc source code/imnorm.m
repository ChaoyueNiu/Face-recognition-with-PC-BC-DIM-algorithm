function [Ihf,Idc,Ion,Ioff,range]=imnorm(I,sigma,gain,leavepadded)
if nargin<2 || isempty(sigma), sigma=2; end
if nargin<3 || isempty(gain), gain=2; end
if nargin<4 || isempty(leavepadded), leavepadded=0; end
pad=ceil(4.*sigma);
I=padarray(I,[pad,pad],'symmetric'); %'replicate');
[a,b]=size(I);

g=gauss2D(sigma);

Idc=conv2(I,g,'same');
Ihf=I-Idc; %so I can be reconstructed as I=Idc+Ihf
%gain=exp(-Idc)
Ihf=gain.*Ihf;
%Ihf=tanh(Ihf);

range{1}=pad+1:a-pad;
range{2}=pad+1:b-pad;
if ~leavepadded
  Ihf=Ihf(range{1},range{2},:);
  Idc=Idc(range{1},range{2},:);
  [a,b]=size(Idc);
  range{1}=1:a;
  range{2}=1:b;
end

Ion=Ihf;   Ion(Ion<0)=0;  
Ioff=-Ihf; Ioff(Ioff<0)=0;

if iszero(Ihf), disp('WARNING: - imnorm gaussian too small, output entirely low frequency'); end
