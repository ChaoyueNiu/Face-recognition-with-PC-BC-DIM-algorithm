function plot_weights(W,toPlot,imDims,plotPolarity)
[a,b]=best_subplot_rows_cols(length(toPlot));
k=0;
for i=toPlot, 
  k=k+1;
  maxsubplot(a,b,k);
  if length(imDims)==3
    %i
    %size(W)
    
    aa = -diff(reshape(W(i,:),imDims),1,3)';
    %size(aa)
    plot_image(aa); 
  elseif length(imDims)==2
    plot_image(reshape(W(i,:),imDims)');
  end
end
cmap=colormap('gray'); if plotPolarity<0, cmap=1-cmap;colormap(cmap); end
set(gcf,'PaperSize',[b a].*imDims(1:2)./max(imDims),'PaperPosition',[0 0 [b a].*imDims(1:2)./max(imDims)]);
