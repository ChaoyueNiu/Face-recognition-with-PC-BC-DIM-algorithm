function plot_RFPPI(stats,style,trials)
TP=stats(:,1);
FP=stats(:,2);
FN=stats(:,3);

fppi=FP./trials;
recall=TP./(TP+FN);
plot(fppi,recall,style,'LineWidth',2,'MarkerSize',8,'MarkerFaceColor',style(1))

set(gca,'FontSize',12);
xlabel('false positives per image')
ylabel('recall')
%axis([0,0.5,0.5,1])
axis([0,1,0,1])
set(gcf,'PaperSize',[8 8],'PaperPosition',[0 0 8 8]);
