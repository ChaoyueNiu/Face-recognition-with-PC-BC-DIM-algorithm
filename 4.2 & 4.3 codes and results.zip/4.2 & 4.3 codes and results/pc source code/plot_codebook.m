function plot_codebook(patches,patchClassList,Locations,indeces)
if nargin<4 || isempty(indeces)
  indeces=1:12;
end

patchLen=sqrt(size(patches,2));
indPatchesInClass=find(patchClassList>0);
indPatchesNonClass=find(patchClassList==0);
numClasses=size(Locations,1);

numClustersToPlot=min(length(indeces),length(indPatchesInClass));
numNonClustersToPlot=min(length(indeces),length(indPatchesNonClass));
numCols=max(numClustersToPlot,numNonClustersToPlot);
for i=1:numClustersToPlot
  %plot voting locations
  for j=1:numClasses
    maxsubplot(numClasses+2,numCols,i+(j-1)*numCols);
    plot_image(Locations{j,indeces(i)});
    colorbar('southoutside')
  end
  %plot patch from cluster
  maxsubplot(numClasses+2,numCols,i+numClasses*numCols); 
  plot_image(reshape(patches(indPatchesInClass(indeces(i)),1:patchLen^2),patchLen,patchLen)); 
end 
for i=1:numNonClustersToPlot
  %plot patch from background cluster
  maxsubplot(numClasses+2,numCols,i+(numClasses+1)*numCols); 
  plot_image(reshape(patches(indPatchesNonClass(i),1:patchLen^2),patchLen,patchLen)); 
end
colormap('gray')
