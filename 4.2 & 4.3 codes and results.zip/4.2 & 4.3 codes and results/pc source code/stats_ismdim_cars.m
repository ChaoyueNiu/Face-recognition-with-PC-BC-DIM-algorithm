function [params,stats]=stats_ismdim_cars(params,thresholds)
if nargin<2 || isempty(thresholds)
  thresholds=[0.1:0.05:2]; 
end
numTest=170;

if nargin<1 || isempty(params)
  spread=2
  amp=1
  
  %DEFINE CODEBOOK
  load('ISMDIM_codebook_cars.mat');

  [Locations,patchClassList]=postprocess_codebook(Locations,patchClassList,spread,amp);
  
  %FOR EACH TEST IMAGE PERFORM ISM TO LOCATE CARS
  disp(['Processing Images (',int2str(numTest),')'])
  params{numTest}=[];%pre-allocate memory
  for i=1:numTest
    fprintf(1,'.%i.',i);
    %load image
    I=load_image_car(i-1,3);
    
    %APPLY ISM-DIM
    [params{i}]=ismdim_matching(I,patches,patchClassList,Locations,sigmaLGN);
  end
end

%FOR EACH THRESHOLD TEST ACCURACY WITH WHICH CARS ARE LOCATED
filename=['estimated_car_locations',int2str(randi(100000)),'.txt']
[~,data_dir]=load_image_car(1,3);
  
disp('Testing Accuracy for threshold:')
t=0;
for thres=thresholds 
  t=t+1;
  fprintf(1,'.%2.2f.',thres);
   
  %record results for current threshold into a file
  file=fopen([data_dir,filename],'w');
  for i=1:numTest
    %find coordinates for which the votes exceed the threshold
    index=find(params{i}{1}(1,:)>thres); 
    coords=params{i}{1}(2:3,index);
      
    %store these coordinates in the results file
    coords=convert_car_coordinates(coords);
    write_result(i,coords,file);
  end    
  fclose(file);
  
  %evaluate the results using the java code supplied with the UIUC Cars dataset
  dir=pwd;
  cd(data_dir);
  [status,result]=system(['java Evaluator trueLocations.txt ',filename]);
  stats(t,:)=parse_car_evaluation(result);
  cd(dir);
  
  f1score(t)=calc_f1score(stats(t,:));
end
disp(' ');

%PLOT THE RESULTS
disp(['f1score ']);
disp(f1score)
[val,ind]=max(f1score); disp(['max f1score=',num2str(val),' at threshold=',num2str(thresholds(ind))]);

figured(11),clf
plot_errors(thresholds,stats,max(sum(stats(:,2:3),2)));

figured(12),clf
plot_precision_recall(stats,'r-^'); hold on

figured(13),clf
plot_RFPPI(stats,'r-^',numTest), hold on



function write_result(i,pos,file)
pos=pos(:);
fprintf(file,'%i: ',i-1);
if ~isnan(pos), fprintf(file,'(%i,%i) ',round(pos)); end
fprintf(file,'\n');



function stats=parse_car_evaluation(result)
vals=sscanf(result,'%*cCorrect detections :%u out of%u%');
TP=vals(1);
FN=vals(2)-vals(1);

ind=strfind(result,'False detections   :');
FP=sscanf(result(ind:end),'False detections   :%u');

stats=[TP,FP,FN];