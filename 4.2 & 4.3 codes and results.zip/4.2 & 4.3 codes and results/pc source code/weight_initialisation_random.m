function [W,V,U]=weight_initialisation_random(n,m,wMean,wStd)
if nargin<3, wMean=0; end
if nargin<4, wStd=0.1; end
%wStd=1/sqrt(m)
%wStd=0.1
W=gaussian_weights(n,m,wMean,wStd);
V=gaussian_weights(n,m,wMean,wStd);
U=gaussian_weights(n,m,wMean,wStd);

%W=gamma_weights(n,m,2,0.05);
%V=gamma_weights(n,m,2,0.05);
%U=gamma_weights(n,m,2,0.05);


function W=gaussian_weights(n,m,wMean,wStd)
W=wMean+wStd.*randn(n,m,'single'); %Gaussian distributed weights with given
W(W<0)=0;           		           %mean and standard deviation				   


function W=gamma_weights(n,m,A,B)
W=single(gamrnd(A,B,n,m)); %Gamma distributed weights
W(W<0)=0;			   

