function [I,data_dir]=load_image_car(num,trainbackgndtest)
data_dir='../../Data/UIUC_Cars/';

if trainbackgndtest==1
  filename=[data_dir,'TrainImages/pos-'];
elseif trainbackgndtest==2
  filename=[data_dir,'TrainImages/neg-'];
elseif trainbackgndtest==3
  filename=[data_dir,'TestImages/test-'];
else
  filename=[data_dir,'TestImages_Scale/test-'];
end
filename=sprintf([filename,'%d.pgm'],num);

I=im2single(imread(filename));
