function patch=extract_patch(I,hlen,coords)
[a,b,c]=size(I);

x1=coords(1)-hlen;
x2=coords(1)+hlen;
y1=coords(2)-hlen;
y2=coords(2)+hlen;

if x1>=1 && x2<=a && y1>=1 && y2<=b
  patch=I([x1:x2],[y1:y2],:);
else
  patch=NaN;
end


