function X=trimarray_symmetrically(X)
%removes rows/columns of zeros from the edges of an array. Does so
%symmetrically, i.e. so the same number of rows are removed from the top as the
%bottom, and so that the same number of colums are removed from both the right
%and left edges.

tmp=sum(X,2); 
cropA=min(min(find(tmp>0))-1,size(X,1)-max(find(tmp>0)));
tmp=sum(X,1); 
cropB=min(min(find(tmp>0))-1,size(X,2)-max(find(tmp>0)));
X=X(cropA+1:size(X,1)-cropA,cropB+1:size(X,2)-cropB); 
