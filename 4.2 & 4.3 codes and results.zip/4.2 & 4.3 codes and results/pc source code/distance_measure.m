function val=distance_measure(v,M,sim) 
%compare row vector, v, to each row of the matrix M

measure='corcoef';%'cosine'; %'correl';%'dim';%%'affinity'; %'correl';%
switch measure
  case 'correl'
    %cross-correlation
    similarity=M*v';
    
  case 'cosine'
    %cosine or normalised cross-correlation
    similarity=M*v';
    norm=sqrt(sum(M.^2,2).*sum(v.^2));
    similarity=similarity./norm;
    
  case 'corcoef'
    %correlation coefficient or zero-mean normalised cross-correlation
    M=bsxfun(@minus,M,mean(M,2)); %subtract mean from each row
    v=v-mean(v);
    similarity=M*v';
    norm=sqrt(sum(M.^2,2).*sum(v.^2));
    similarity=similarity./norm;
  
  case 'euclid'
    M=bsxfun(@minus,M,v);
    dist=sqrt(sum(M.^2,2));
    similarity=1-dist;
    
  case 'affinity'
    sigma=10
    M=bsxfun(@minus,M,v);
    similarity=exp(-0.5.*(sum(M.^2,2))./sigma.^2);
    
  case 'dim'
    %M=bsxfun(@minus,M,mean(M,2)); %subtract mean from each row
    %v=v-mean(v);
    
    %M=[max(0,M),max(0,-M)];
    %v=[max(0,v),max(0,-v)];

    %M=bsxfun(@rdivide,M,max(M,[],2));
    %M=[M,1-M]; v=[v,1-v];
    
    W=bsxfun(@rdivide,M,max(1e-6,sum(abs(M),2)));%normalise FF weights
    similarity=dim_activation(W,v');
    %similarity=similarity./max(1,max(similarity)); %ensure valid value (<=1)
    
  case 'hausdorff' 
    %assume vector and matrix rows represent square patches
    a=sqrt(length(v));
    v=reshape(v,a,a);
    [x1,y1]=find(v>0.5);
    for i=1:size(M,1)
      m=reshape(M(i,:),a,a);
      [x2,y2]=find(m>0.5);
      dist(i)=HausdorffDist([x1,y1],[x2,y2],1);
    end
    similarity=1-dist;
    
  case 'edgedist'
    %assume vector and matrix rows represent square patches
    sumv=sum(v);
    summ=sum(M,2);
    a=sqrt(length(v));
    v=reshape(v,a,a);
    distv=bwdist(v);
    for i=1:size(M,1)
      if summ(i)==0 || sumv==0
        dist(i)=Inf;
      else
        m=reshape(M(i,:),a,a);
        %dist(i)=sum(sum(v.*bwdist(m)))./summ(i)+sum(sum(distv.*m))./sumv;
        dist(i)=max(sum(sum(v.*bwdist(m)))./sumv,sum(sum(distv.*m))./summ(i));%A
        %dist(i)=max(sum(sum(v.*bwdist(m)))./sumv,sum(sum(distv.*m))./summ(i))./(a/2);%C
      end
    end
    similarity=1-dist;

  otherwise
    disp('ERROR: unknown distance measure');
end

if nargin>2 && sim
  %return similarity rather than distance
  val=similarity;
else
  %return distance
  val=1-similarity;
end