function [W,V]=dim_learn(W,V,y,e,beta,alpha)

if nargin<5 || isempty(beta), beta=0.1; end %learning rate, controls how fast weights can change
if nargin<6 || isempty(alpha), alpha=0.3; end %controls learning parts (small) or wholes (large) 
[n,m]=size(W);
[n,batchLen]=size(y);

y(y>1e6)=1e6; %limit y to avoid NaN's in weight updates (can alternatively limit
              %y in activation function, with similar results)
ye=y*e';
Y=y*ones(batchLen,m);
Vw=bsxfun(@rdivide,W,max(1e-2,max(W,[],2)));

%update feedforward weights
delta=ye - Y.*( repmat(sum(W,2),1,m) + alpha.*Vw ); 
change=max(abs(delta),[],2);
W=W+beta.*delta.*repmat(max(W,[],2)./max(1,change),1,m);
W(W<0)=0;

if nargout>1
  %update feedback weights
  delta=ye - Y.*( repmat(max(V,[],2),1,m) + alpha.*V );
  change=max(abs(delta),[],2);
  V=V+beta.*delta.*repmat(max(V,[],2)./max(1,change),1,m);
  V(V<0)=0;
end
