function test_ismdim_carsScale(imageNum,threshold,paramsAllImages)
if nargin<1 || isempty(imageNum) || imageNum<0
  imageNum=0
end
if nargin<2 || isempty(threshold) || threshold<0
  threshold=0.64
end
scales=1.2.^[-1:4] %6 scales

makeScaleLarge=1;%./min(scales)
scales=scales.*makeScaleLarge

%DEFINE TEST IMAGE
I=load_image_car(imageNum,4);

I=imresize(I,makeScaleLarge,'bilinear');

if nargin<3 || isempty(paramsAllImages)
  spread=2
  amp=2;

  %DEFINE CODEBOOK
  load('ISMDIM_codebook_carsScale.mat'); 

  [Locations,patchClassList]=postprocess_codebook(Locations,patchClassList,spread,amp,scales);

  %APPLY ISM-DIM TO  TEST IMAGE TO LOCATE CARS
  [params]=ismdim_matching(I,patches,patchClassList,Locations,sigmaLGN,scales);
else
  params=paramsAllImages{imageNum+1};
end
  
%display detected locations and plot bounding boxes

index=find(params{1}(1,:)>threshold); 
amplitude=params{1}(1,index);
coords=params{1}(2:3,index);
scale=params{1}(4,index);

coords=coords./makeScaleLarge;
scale=scale./makeScaleLarge;
I=imresize(I,1/makeScaleLarge,'bilinear');

[coords,widths,heights]=convert_car_coordinates(coords,scale);

figured(3), clf, plot_image(I), hold on
plot_bounding_box(coords,widths,heights);
set(gcf,'PaperSize',[20 15],'PaperPosition',[0 0 20 15]);
colormap('gray');
drawnow;

%move to before "convert_car_coordinates" to report centre locations
disp(' * amplitude:');
disp(amplitude);
disp(' * coords:');
disp(coords);
disp(' * scale:');
disp(scale);


