function [Locations,patchClassList]=postprocess_codebook(Locations,patchClassList,voteSpread,voteAmp,scales,reScale,flip)
%    voteSpread - the standard deviation of the Gaussian used to smooth the Locations

indPatchesInClass=find(patchClassList>0);
numCodebookEntries=length(indPatchesInClass);
numClasses=size(Locations,1);

if nargin>3 && ~isempty(voteAmp) && voteAmp~=1
  %increase strength of voting weights
  for i=1:numCodebookEntries
    for c=1:numClasses
      Locations{c,i}=voteAmp.*Locations{c,i};
    end
  end
  disp('amplified all voting weights');
end

if nargin<5 || isempty(scales)
  if numClasses>1
    %equalize strength of voting weights between classes - imposes a uniform prior on class membership
    p=zeros(1,numClasses);
    for c=1:numClasses
      for i=1:numCodebookEntries
        p(c)=p(c)+sum(sum(Locations{c,i})); 
      end
    end
    p
    pmax=max(p)
    for c=1:numClasses
      for i=1:numCodebookEntries
        Locations{c,i}=Locations{c,i}.*pmax./p(c);
      end
    end
    disp('equalised voting weights across classes');
  end
  
  %smooth codebook entries across spatial position
  gauss=gauss2D(voteSpread);
  for i=1:numCodebookEntries
    for c=1:numClasses
      %gauss=gauss2D(voteSpread.*scales(c));
      Locations{c,i}=conv2(Locations{c,i},gauss,'same');
      Locations{c,i}=single(Locations{c,i});
    end
  end
  disp('spatially smoothed voting weights');
else
  %smooth codebook entries across spatial position and scale
  sigmaScale=0.5
  gauss=gauss3D([voteSpread,voteSpread,sigmaScale]);
  if nargin<6 || isempty(reScale) || reScale==0
    %process multiscale codebook
    for i=1:numCodebookEntries
      [a,b]=size(Locations{find(scales==1),i});
      allLocations=[];
      %make vote weight arrays for different scales the same size, and place in a
      %single array, in order to be able to smooth across them
      for c=1:numClasses
        origSize{c}(1:2)=size(Locations{c,i});
        allLocations(:,:,c)=imresize(Locations{c,i},[a,b],'bilinear');
      end
      allLocations=convn(allLocations,gauss,'same');
      %return vote weight arrays to original sizes
      for c=1:numClasses
        Locations{c,i}=(scales(c).^2).*imresize(allLocations(:,:,c),origSize{c},'bilinear');
        %Locations{c,i}=conv2(Locations{c,i},gauss2D(voteSpread),'same');                          %0.78
        %Locations{c,i}=(scales(c).^2).*conv2(Locations{c,i},gauss2D(voteSpread),'same');          %0.95
        %Locations{c,i}=(scales(c).^2).*conv2(Locations{c,i},gauss2D(voteSpread*scales(c)),'same');%0.96
       
        Locations{c,i}=single(Locations{c,i});
     end
    end
    disp('smoothed voting weights across space and scale');
  else
    %convert a single scale codebook into a multiscale one
    numScales=length(scales);
    if numClasses>1
      error(1,'can not convert codebook to mutiscale if there is more than one class');
    end
    [a,b]=size(Locations{1,1});
    
    patchClassListRescaled=[];
    for s=1:numScales
      for i=1:numCodebookEntries*numScales
        LocationsRescaled{s,i}=0;
      end
      for i=1:numCodebookEntries
        LocationsRescaled{s,(s-1)*numCodebookEntries+i}=Locations{1,i};  
      end
      patchClassListRescaled=[patchClassListRescaled,patchClassList.*s];
    end
    patchClassList=patchClassListRescaled;
    disp('expanded single-scale coodebook into a multiscale codebook (Locations)')
    for i=1:numCodebookEntries*numScales
      allLocations=zeros(a,b,'single');
      %place vote weight arrays for different scales into the same array, in order to be able
      %to smooth across them
      for s=1:numScales
        allLocations(:,:,s)=LocationsRescaled{s,i};
      end
      allLocations=convn(allLocations,gauss,'same');
      %resize vote weight arrays to be appropriate for scale
      for s=1:numScales
        Locations{s,i}=(scales(s).^2).*imresize(allLocations(:,:,s),scales(s),'bilinear');
        Locations{s,i}=single(Locations{s,i});
      end
    end
    disp('smoothed voting weights across space and scale');
  end
end

[numClasses,numCodebookEntries]=size(Locations);
for i=1:numCodebookEntries
  for c=1:numClasses
    Locations{c,i}=trimarray_symmetrically(Locations{c,i});
  end
end
disp('trimmed zeros from edges of voting weights');

if nargin>6 && flip==1
  for i=1:numCodebookEntries
    for c=1:numClasses
      %Locations{c+numClasses,i}=fliplr(Locations{c,i}); %treat as separate classes
      Locations{c,i+numCodebookEntries}=fliplr(Locations{c,i}); %treat as same class
    end
  end
  patchClassList=[patchClassList,patchClassList]; %treat as same class
  disp('added flipped voting weights to codebook');
end

disp('finished postprocessing codebook')