function I=imsetsize(I,sz,fill)
if nargin<3 || isempty(fill), fill='replicate'; end
[a,b]=size(I);
pad=max(0,[sz(1)-a,sz(2)-b]);
crop=max(0,[a-sz(1),b-sz(2)]);

I=I(floor(crop(1)/2)+1:a-ceil(crop(1)/2),floor(crop(2)/2)+1:b-ceil(crop(2)/2));
I=padarray(I,floor(pad./2),fill,'pre');
I=padarray(I,ceil(pad./2),fill,'post');

