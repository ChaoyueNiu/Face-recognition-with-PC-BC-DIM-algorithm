function test_ismdim_cars(imageNum,threshold)
if nargin<1 || isempty(imageNum) || imageNum<0
  imageNum=0
end
if nargin<2 || isempty(threshold) || threshold<0
  threshold=0.925
end
spread=2

%DEFINE CODEBOOK
load('ISMDIM_codebook_cars.mat'); 

Locations=postprocess_codebook(Locations,patchClassList,spread);

%DEFINE TEST IMAGE
I=load_image_car(imageNum,3);

%APPLY ISM-DIM
[params]=ismdim_matching(I,patches,patchClassList,Locations,sigmaLGN);

%display detected locations and plot bounding boxes

index=find(params{1}(1,:)>threshold); 
amplitude=params{1}(1,index);
coords=params{1}(2:3,index);

[coords,widths,heights]=convert_car_coordinates(coords);

figured(3), clf, plot_image(I), hold on
plot_bounding_box(coords,widths,heights);
set(gcf,'PaperSize',[20 15],'PaperPosition',[0 0 20 15]);
colormap('gray');
drawnow;

%move to before "convert_car_coordinates" to report centre locations
disp(' * amplitude:');
disp(amplitude);
disp(' * coords:');
disp(coords);

