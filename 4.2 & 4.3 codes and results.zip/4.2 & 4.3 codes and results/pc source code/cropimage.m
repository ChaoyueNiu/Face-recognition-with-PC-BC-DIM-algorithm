function I=cropimage(I,crop)
[a,b]=size(I);
I=I(crop+1:a-crop,crop+1:b-crop);