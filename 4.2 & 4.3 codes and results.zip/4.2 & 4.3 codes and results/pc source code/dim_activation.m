function [y,e,r]=dim_activation(W,x,V,y,iterations)
[n,m]=size(W);
[nInputChannels,batchLen]=size(x);

if nargin<4 || isempty(y)
  y=zeros(n,batchLen,'single'); %initialise prediction neuron outputs
end
if nargin<3 || isempty(V) 
  %set feedback weights equal to feedforward weights normalized by maximum value 
  V=bsxfun(@rdivide,W,max(1e-6,max(W,[],2)));
end
V=V'; %avoid having to take transpose at each iteration

%set parameters
if nargin<5 || isempty(iterations), iterations=50; end
epsilon2=1e-2;
epsilon1=epsilon2/max(sum(V,2));

%iterate to find steady-state response to input
%ediff=Inf; ymax=0; eprev=0; ymaxprev=max(y);
%t=0; while t<iterations && (ediff>0.1 || ymax<0.1), t=t+1;
for t=1:iterations
  %update responses
  r=V*y;
  e=x./max(epsilon2,r);
  %e=x./(epsilon2+r);
  y=max(epsilon1,y).*(W*e);
  %y=(epsilon1+y).*(W*e);
 
  %ediff=max(abs(e-eprev));
  %eprev=e;
  %ymax=ymaxprev;
  %ymaxprev=max(y);
end	
%fprintf(1,'dim complete: t=%i, ediff=%f, ymax=%f\n',t,ediff,ymax)
