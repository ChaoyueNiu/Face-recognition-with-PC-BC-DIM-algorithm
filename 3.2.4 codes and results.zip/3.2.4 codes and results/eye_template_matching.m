clear all
clc
close
qq=imread('testing image 1.jpg'); 
qq1=imread('tesying image 1 eye template.png'); 
q=rgb2gray(qq);
q1=rgb2gray(qq1); 
[px1,py1]=size(q1); 
for i=1:300
    for j=1:250
           rect=[i j py1-1 px1-1];
           q2=imcrop(q,rect);
           r(i,j)=corr2(q1,q2);
           objvalue(i,j)=[(r(i,j)+1)/2]^2;
     end
end
z=objvalue(1,1); 
 for i=1:300
     for j=1:250
         if objvalue(i,j)>z
             z=objvalue(i,j);
             x=i;
             y=j;
         end
     end
 end
bx=[x x+py1-1 x+py1-1 x];
by=[y y y+3*px1-1 y+3*px1-1];
BW=roipoly(q,bx,by);
bx1=[x-1 x+py1 x+py1 x-1];
by1=[y-1 y-1 y+3*px1 y+3*px1];
BW1=roipoly(q,bx1,by1);
BW2=BW1-BW;
q3=double(q)/255; 
Q=q3+BW2; 
figure,imshow(Q);


