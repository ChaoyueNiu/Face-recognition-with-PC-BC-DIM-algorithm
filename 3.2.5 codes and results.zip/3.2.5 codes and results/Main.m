%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Robust Real Time Face Detection %%%%%%%
%%%%%%%% Image Project %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% 1394/05/8 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
clc;
close all;
clear;
picture1 = imread ('testing image 3.bmp');

ConvertHaarcasadeXMLOpenCV('HaarCascades/haarcascade_frontalface_alt.xml');
FilenameHaarcasade = 'HaarCascades/haarcascade_frontalface_alt.mat';
Objects=ObjectDetection(picture1,FilenameHaarcasade);
ShowDetectionResult(picture1,Objects);