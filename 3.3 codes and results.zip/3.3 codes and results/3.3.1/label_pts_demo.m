function pts = label_pts_demo(imgName)

Learn_Num_Parts = 2;

img = imread(imgName);

img_pre = img;
imagesc(img_pre);
hold on;
daspect([1 1 1]);
colormap(gray);
title('click right button to revise the last point');

num_clicked = 0;
while(num_clicked<=Learn_Num_Parts) 
    
    num_clicked = num_clicked+1;
    
    [x(num_clicked), y(num_clicked),b] = ginput(1);
    
    if (b==1) 
        
        plot(x(num_clicked),y(num_clicked),'rx');
        
    elseif (b==3) 
        if (num_clicked>1)
            num_clicked = num_clicked-1;
          
            plot(x(num_clicked),y(num_clicked),'kx');
           
            num_clicked = num_clicked-1;
        else
            num_clicked = num_clicked-1;
        end
        
    else
        num_clicked = num_clicked - 1;
       
    end
end
hold off;  

x = round(x);
y = round(y);

pts = [x(1), y(1) x(2), y(2)];

close all






