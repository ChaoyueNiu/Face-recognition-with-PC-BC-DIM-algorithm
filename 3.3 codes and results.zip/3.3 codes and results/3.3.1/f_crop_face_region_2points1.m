function F = f_crop_face_region_2points1(im, source, dest,inSize)

inputpt=[source(1:2);source(3:4)];
basept=[dest(1:2); dest(3:4)];
trans = cp2tform(inputpt, basept, 'linear conformal');  

normImages = imtransform(im, trans, 'bicubic', ...
    'xdata',[1,inSize(1)], 'ydata',[1,inSize(2)]);      
F = normImages;



