function getAlignedFace_demo()

close all


[imgName, PathName] = uigetfile('*.*', 'window title', 'att_faces/orl_faces/');

Path = strsplit(PathName, '\\');
img = strsplit(imgName, '.');
img = img(1);
pts = label_pts_demo(fullfile(PathName, imgName));

im = imread(fullfile(PathName, imgName));

croppedFace = my_alignment_2points_demo(im, pts);


dir_ = Path(end-1);

if ~exist(dir_{1}, 'dir')
    mkdir(dir_{1})
end

path = [dir_{1}, '/', img{1}, '.jpg'];
imwrite(croppedFace, path);






