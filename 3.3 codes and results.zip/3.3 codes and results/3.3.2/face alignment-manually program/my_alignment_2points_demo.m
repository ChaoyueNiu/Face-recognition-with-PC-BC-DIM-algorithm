function F = my_alignment_2points_demo(im, pts)
%%im is the image to be transfromed, pts is the coordinate of landmarks in the input image,
%with the form [x1 y1 x2 y2]

inSize = [64, 64];
outLE = [16, 20];
outRE = [48, 20];

F = f_crop_face_region_2points1(im, pts, [outLE outRE], inSize);

