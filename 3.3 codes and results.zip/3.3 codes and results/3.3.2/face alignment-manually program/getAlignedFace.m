function getAlignedFace()

debug_state = 1;
imsize = [100, 100];


imdir_normal = 'F:\����������\CAS-PEAL-R1_JPG\FRONTAL\Lighting\';
saveFacedir_normal = 'C:\�㷨����\label_allign_face\tmpPic\';



[fileName, ReyeX, ReyeY, LeyeX, LeyeY] = textread('ptsInfo.txt', '%s%d%d%d%d');


imMat = zeros(length(fileName), imsize(1)*imsize(2));
tip = 0;
for lp = 1:length(fileName)
    tip = tip + 1;
    
    fileName_tmp = fileName{lp};
    im = imread(fullfile(imdir_normal, fileName_tmp));
    pts = [ReyeX(lp), ReyeY(lp), LeyeX(lp), LeyeY(lp)];

    croppedFace = my_alignment_2points(im, pts);

    croppedFace = imresize(croppedFace, imsize, 'bilinear');
    imMat(tip, :) = croppedFace(:)';
    
    if debug_state

        figure(1);
        subplot(1, 2, 1);
        imshow(im);
        hold on
        plot(pts(1), pts(2), 'g+')
        plot(pts(3), pts(4), 'g+');

        hold off
        title('disturbed eye position in raw figure(red cross)');

        subplot(1, 2, 2);
        imshow(croppedFace);
        title(['allgned face ',num2str(tip)]);
        pause();
        if tip>10
            close all
            return;
        end
    else
        imwrite(croppedFace, fullfile(saveFacedir_normal, fileName_tmp));
    end
end



save allignedFace.mat  imMat 


