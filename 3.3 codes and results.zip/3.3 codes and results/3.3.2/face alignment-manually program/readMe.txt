the original code is from http://www.pudn.com/. 
In this code, I have modified some area . 
If you want to change the size of image, please modify face alignment program��my_alignment_2points_demo.m
run the getAlignedFace_demo.m 
main program��getAlignedFace_demo.m
mark eyes program��label_pts_demo.m
face alignment program��my_alignment_2points_demo.m


